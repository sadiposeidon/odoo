{
    'name': 'Overmetal Custom Reports',
    'version': '18.0.1.1',
    'summary': 'Faktura, Satış, Satın Alma və Protokol Hesabatları',
    'category': 'Operations',
    'author': 'Overmetal',
    'depends': ['account', 'web', 'sale', 'purchase'],  # Satış və Satın alma əlavə edildi
    'data': [
        'reports/report_actions.xml',
        'reports/report_invoice_template.xml',
        'reports/report_sale_template.xml',       # Yeni
        'reports/report_purchase_template.xml',   # Yeni
        'reports/report_protocol_template.xml',   # Yeni
        'views/account_move_views.xml',
        'views/sale_order_views.xml',             # Yeni
        'views/purchase_order_views.xml',         # Yeni
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}