from odoo import models

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_preview_sale_report(self):
        report_name = 'overmetal_reports.template_overmetal_sale'
        return {
            'type': 'ir.actions.act_url',
            'url': f'/report/html/{report_name}/{self.id}',
            'target': 'new',
        }

    # PDF Yükləmə - Qiymət Təklifi
    def action_download_sale_pdf(self):
        return self.env.ref('overmetal_reports.action_overmetal_sale_pdf').report_action(self)

    def action_preview_protocol_report(self):
        report_name = 'overmetal_reports.template_overmetal_protocol'
        return {
            'type': 'ir.actions.act_url',
            'url': f'/report/html/{report_name}/{self.id}',
            'target': 'new',
        }

    # PDF Yükləmə - Protokol
    def action_download_protocol_pdf(self):
        return self.env.ref('overmetal_reports.action_overmetal_protocol_pdf').report_action(self)