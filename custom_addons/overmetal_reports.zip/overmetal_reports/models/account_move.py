from odoo import models

class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_preview_overmetal_report(self):
        # Hesabatın tam texniki adını bura qeyd edirik
        report_name = 'overmetal_reports.template_overmetal_invoice'
        return {
            'type': 'ir.actions.act_url',
            'url': f'/report/html/{report_name}/{self.id}',
            'target': 'new',
        }

    def action_download_invoice_pdf(self):
        return self.env.ref('overmetal_reports.action_overmetal_invoice_pdf').report_action(self)