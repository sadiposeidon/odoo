from odoo import models

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def action_preview_purchase_report(self):
        report_name = 'overmetal_reports.template_overmetal_purchase'
        return {
            'type': 'ir.actions.act_url',
            'url': f'/report/html/{report_name}/{self.id}',
            'target': 'new',
        }

    # PDF Yükləmə - Satın Alma
    def action_download_purchase_pdf(self):
        return self.env.ref('overmetal_reports.action_overmetal_purchase_pdf').report_action(self)