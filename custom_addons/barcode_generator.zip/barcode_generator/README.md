# Barcode Generator (Odoo 18)

This module automatically generates a unique barcode for products when they are created.

## Features
- Automatic barcode generation on product creation
- Configurable barcode prefix
- Configurable total barcode length
- Barcode ends with product ID
- Conflict-free (safe for concurrent users)
- Settings configurable via Odoo Settings UI

## Barcode Format
	Example:
		- Prefix: 20
		- Total length: 13
		- Product ID: 10

### Result:
	- 2000000000010

## Configuration
Go to:
**Settings → General Settings → Barcode Generator**

Set:
- Barcode Prefix
- Barcode Total Length

## Compatibility
- Odoo 18
- PostgreSQL
- Multi-user safe

## Author
Sadiq Abishov
