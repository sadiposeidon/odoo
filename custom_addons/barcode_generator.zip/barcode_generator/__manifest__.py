{
    "name": "Barcode Generator",
    "version": "18.0.1.0.0",
    "summary": "Məhsullar üçün avtomatik unikal barkodların yaradılması",
    "description": """
Bu modul Odoo 18 üçün məhsul idarəetməsini asanlaşdırmaq üçün hazırlanmışdır. 
Məhsul yaradılan zaman sistem avtomatik olaraq müəyyən edilmiş formatda unikal barkod təyin edir.

Əsas Xüsusiyyətlər
==================
* **Avtomatik Yaradılma:** Yeni məhsul əlavə edildikdə barkodun avtomatik təyin edilməsi.
* **Ağıllı Toqquşma Həlli:** Barkod başqa məhsulda tapıldıqda, sistem sizə xəbərdarlıq edir və köhnə məhsulun barkodunu avtomatik bərpa etməyə imkan verir.
* **Dublikat Qoruması:** Barkodun bazada tam unikal olması həm kod, həm də SQL səviyyəsində təmin edilir.
* **Fərdi Format:** Tənzimləmələr bölməsindən barkodun ön şəkilçisini (Prefix) və ümumi uzunluğunu təyin etmək imkanı.
* **Manual İdarəetmə:** Məhsul kartı üzərindəki xüsusi düymələr vasitəsilə barkodu tək kliklə yaratmaq və ya təmizləmək funksiyası.
* **Tam İnteqrasiya:** Həm əsas məhsul şablonlarında (Template), həm də məhsul variantlarında (Product) problemsiz işləyir.

Üstünlükləri
============
* **Zaman Qənaəti:** Hər bir məhsul üçün əllə barkod daxil etməyə ehtiyac qalmır.
* **Məlumat Dürüstlüyü:** Toqquşma idarəetməsi sayəsində barkod ziddiyyətləri saniyələr içində həll olunur.
* **Xətaların Qarşısının Alınması:** Təkrarlanan və ya səhv formatlı barkodların yaranma riski aradan qalxır.
* **Standartlaşdırma:** Şirkətdaxili məhsul bazasında vahid barkod standartı qorunur.
""",
    "author": "Sadiq Abışov - Hafiz Məcidov",
    "category": "Inventory",
    "depends": ["base", "product", "sale", "purchase", "stock", "account"],
    "data": [
        "security/ir.model.access.csv",
        "views/barcode_collision_wizard_view.xml",
        "views/res_config_settings_view.xml",
        "views/product_view.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
    "license": "LGPL-3",
}