from odoo import models, fields, api

class BarcodeCollisionWizard(models.TransientModel):
    _name = 'barcode.collision.wizard'
    _description = 'Barkod Toqquşması Həlli'

    product_id = fields.Many2one('product.product', string="Cari Məhsul")
    conflict_product_id = fields.Many2one('product.product', string="Ziddiyyətli Məhsul")
    barcode = fields.Char(string="Toqquşan Barkod")
    message = fields.Text(string="Mesaj", readonly=True)

    def action_fix_conflict(self):
        """Ziddiyyətli məhsulun barkodunu onun ID-si ilə yeniləyir və cari məhsula barkod verir"""
        self.ensure_one()
        # Ziddiyyətli məhsulun barkodunu öz ID-sinə görə bərpa edirik
        new_conflict_barcode = self.conflict_product_id.product_tmpl_id._generate_barcode_logic(force_id=self.conflict_product_id.id)
        self.conflict_product_id.barcode = new_conflict_barcode
        
        # İndi cari məhsula istədiyi barkodu verə bilərik
        self.product_id.barcode = self.barcode
        return {'type': 'ir.actions.act_window_close'}