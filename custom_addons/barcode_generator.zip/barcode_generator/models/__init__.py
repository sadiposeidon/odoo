from . import product
from . import res_config_settings
from . import barcode_collision_wizard