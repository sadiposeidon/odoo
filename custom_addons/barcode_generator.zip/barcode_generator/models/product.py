from odoo import models, fields, api, _

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    def _generate_barcode_logic(self, force_id=None):
        """Barkod yaratma məntiqi: force_id ötürüldükdə həmin ID-ni istifadə edir"""
        self.ensure_one()
        ICP = self.env['ir.config_parameter'].sudo()
        prefix = ICP.get_param('barcode_generator.barcode_prefix', '20')
        length_param = ICP.get_param('barcode_generator.barcode_total_length', '13')
        
        try:
            length = int(length_param)
        except ValueError:
            length = 13

        # Əgər xüsusi ID verilməyibsə, cari məhsulun ID-sini götürür
        record_id = force_id or (self.id if isinstance(self.id, int) else 0)
        suffix_length = length - len(prefix)
        
        if suffix_length <= 0:
            suffix = str(record_id)
        else:
            suffix = str(record_id).zfill(suffix_length)
            
        return f"{prefix}{suffix}"

    def action_generate_barcode(self):
        for record in self:
            if not record.barcode:
                new_barcode = record._generate_barcode_logic()
                
                # Toqquşmanı (Dublikatı) yoxlayırıq
                conflict_product = self.env['product.product'].search([('barcode', '=', new_barcode)], limit=1)
                
                if conflict_product:
                    # Əgər barkod başqa məhsulda varsa, Wizard pəncərəsini açırıq
                    message = _("Yaradılacaq barkod (%s) artıq '%s' (ID: %s) adlı məhsulda istifadə edilir.") % (
                        new_barcode, conflict_product.display_name, conflict_product.id
                    )
                    return {
                        'name': _('Barkod Toqquşması Tapıldı'),
                        'type': 'ir.actions.act_window',
                        'res_model': 'barcode.collision.wizard',
                        'view_mode': 'form',
                        'target': 'new',
                        'context': {
                            'default_product_id': record.product_variant_id.id,
                            'default_conflict_product_id': conflict_product.id,
                            'default_barcode': new_barcode,
                            'default_message': message,
                        }
                    }
                
                record.barcode = new_barcode

    def action_clear_barcode(self):
        for record in self:
            record.barcode = False

    @api.model_create_multi
    def create(self, vals_list):
        records = super(ProductTemplate, self).create(vals_list)
        for record in records:
            if not record.barcode:
                # Yeni yaradılan məhsul üçün birbaşa barkod təyin edirik
                record.barcode = record._generate_barcode_logic()
        return records

class ProductProduct(models.Model):
    _inherit = 'product.product'

    _sql_constraints = [
        ('barcode_uniq', 'unique(barcode)', 'Bu barkod artıq başqa bir məhsulda istifadə olunub!'),
    ]

    def action_generate_barcode(self):
        """Variant səviyyəsində barkod yaratma"""
        for record in self:
            if not record.barcode:
                new_barcode = record.product_tmpl_id._generate_barcode_logic(force_id=record.id)
                
                conflict_product = self.env['product.product'].search([('barcode', '=', new_barcode)], limit=1)
                
                if conflict_product:
                    message = _("Yaradılacaq barkod (%s) artıq '%s' (ID: %s) adlı məhsulda istifadə edilir.") % (
                        new_barcode, conflict_product.display_name, conflict_product.id
                    )
                    return {
                        'name': _('Barkod Toqquşması Tapıldı'),
                        'type': 'ir.actions.act_window',
                        'res_model': 'barcode.collision.wizard',
                        'view_mode': 'form',
                        'target': 'new',
                        'context': {
                            'default_product_id': record.id,
                            'default_conflict_product_id': conflict_product.id,
                            'default_barcode': new_barcode,
                            'default_message': message,
                        }
                    }
                record.barcode = new_barcode

    def action_clear_barcode(self):
        for record in self:
            record.barcode = False

    @api.model_create_multi
    def create(self, vals_list):
        records = super(ProductProduct, self).create(vals_list)
        for record in records:
            if not record.barcode:
                record.barcode = record.product_tmpl_id._generate_barcode_logic(force_id=record.id)
        return records