# from odoo import models, fields, api

# class ResConfigSettings(models.TransientModel):
#     _inherit = 'res.config.settings'

#     barcode_prefix = fields.Char(string='Barcode Prefix', default='20')
#     barcode_length = fields.Integer(string='Barcode Total Length', default=13)

#     def set_values(self):
#         super(ResConfigSettings, self).set_values()
#         self.env['ir.config_parameter'].sudo().set_param('barcode_generator.prefix', self.barcode_prefix)
#         self.env['ir.config_parameter'].sudo().set_param('barcode_generator.length', self.barcode_length)

#     @api.model
#     def get_values(self):
#         res = super(ResConfigSettings, self).get_values()
#         res.update(
#             barcode_prefix=self.env['ir.config_parameter'].sudo().get_param('barcode_generator.prefix', default='20'),
#             barcode_length=int(self.env['ir.config_parameter'].sudo().get_param('barcode_generator.length', default=13)),
#         )
#         return res

from odoo import fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    barcode_prefix = fields.Char(
        string="Barkod Ön Şəkilçisi", 
        config_parameter='barcode_generator.barcode_prefix', 
        default='20'
    )
    barcode_total_length = fields.Integer(
        string="Barkod Tam Uzunluğu", 
        config_parameter='barcode_generator.barcode_total_length', 
        default=13
    )

